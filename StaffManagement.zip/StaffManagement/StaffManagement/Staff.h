#ifndef STAFF_H
#define STAFF_H

#include <string>
#include <utility>

typedef std::pair<std::string, std::string> td_FULL_NAME;

class Staff {
public:
	Staff(int _id);
	~Staff();
	void printInfo();

	int getId();

	void setName(std::string _name);
	std::string  getName();

	void setContractStart(std::string _date);
	std::string getContractStart();

	void setContractEnd(std::string _date);
	std::string getContractEnd();

	void setSalary(int _salary);
	int getSalary();

private:
	int id;
	std::string name;
	std::string contract_start, contract_end;
	int salary;
};

#endif // !STAFF_H

