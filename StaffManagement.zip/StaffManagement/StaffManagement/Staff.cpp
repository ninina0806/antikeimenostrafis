#include "Staff.h"
#include "Core.h"
#include <list>
#include <iostream>
#include <vector>


Staff::Staff(int _id):salary(0), id(_id) {}

Staff::~Staff(){}

int Staff::getId() { return id; }

void Staff::setName(std::string _name) { name = _name; }
std::string Staff::getName() { return name; }

void Staff::setContractStart(std::string _date) { contract_start = _date; }
std::string Staff::getContractStart() { return contract_start; }

void Staff::setContractEnd(std::string _date) { contract_end = _date; }
std::string Staff::getContractEnd() { return contract_end; }

void Staff::setSalary(int _salary) { salary = _salary; }
int Staff::getSalary() { return salary; }

void Staff::printInfo() {
	std::string info;
	std::string line_separator = "\n";
	std::vector<std::string> names{ Core::explode(name, ' ') };
	info += "------------------" + line_separator;
	info += "ID: #" + std::to_string(id) + " " + line_separator;
	info += "Name: " + names[0] + " " + names[1] + line_separator;
	info += "Contract: " + contract_start + " - " + contract_end + line_separator;
	info += "Salary: " + std::to_string(salary) + " Euros" + line_separator;
	info += "------------------" + line_separator;
	std::cout << info << std::endl;
}


