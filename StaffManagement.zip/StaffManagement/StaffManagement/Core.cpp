#include "Core.h"
#include <fstream>
#include <map>
#include <iostream>

std::map<Months, int> days_of_month;
bool APP_IS_ON = true;

void Core::init() {
	days_of_month.insert(std::pair<Months, int>(JANUARY,	31));
	days_of_month.insert(std::pair<Months, int>(FEBRUARY,	28));
	days_of_month.insert(std::pair<Months, int>(MARCH,		31));
	days_of_month.insert(std::pair<Months, int>(APRIL,		30));
	days_of_month.insert(std::pair<Months, int>(MAY,		31));
	days_of_month.insert(std::pair<Months, int>(JUNE,		30));
	days_of_month.insert(std::pair<Months, int>(JULY,		31));
	days_of_month.insert(std::pair<Months, int>(AUGUST,		31));
	days_of_month.insert(std::pair<Months, int>(SEPTEMBER,	30));
	days_of_month.insert(std::pair<Months, int>(OCTOMBER,	31));
	days_of_month.insert(std::pair<Months, int>(NOVEMBER,	30));
	days_of_month.insert(std::pair<Months, int>(DECEMBER,	31));

	APP_IS_ON = true;
}

bool Core::isAppRunning() { return APP_IS_ON;  }
void Core::stopApp() { APP_IS_ON = false; }

bool Core::formatDate(int _day, int _month, int _year, std::string& _date) {
	if (checkDate(_day, _month, _year)) {
		std::string date_seperator = "/";
		_date = std::to_string(_day) + date_seperator + std::to_string(_month) + std::to_string(_year);
		return true;
	}
	return false;
}

bool Core::checkDate(int _day, int _month, int _year) {
	if (_month < JANUARY || _month > DECEMBER) return false;
	int valid_days = days_of_month[Months(_month)];
	if (_month == FEBRUARY && isLeapYear(_year)) valid_days = 29;
	if (_day < 1 || _day > valid_days) return false;
	return true;
}

bool Core::isLeapYear(int _year) {
	if (_year % 4 != 0) return false;
	if (_year % 100 != 0) return true;
	if (_year % 100 == 0 && _year % 400 == 0) return true;
	else return false;
}

bool Core::checkInput(std::string _input) {
	return _input.length() > 0;
}

bool Core::openFile(std::string _filename, int _mode, std::fstream*& _file) {
	_file = new std::fstream(_filename, _mode);
	if (!_file->good()) {
		_file->close();
		delete _file;
		_file = NULL;
		return false;
	}
	return true;
	
}

std::vector<std::string> Core::explode(const std::string& s, const char& c)
{
	std::string buff{ "" };
	std::vector<std::string> v;

	for (auto n : s)
	{
		if (n != c) buff += n;
		else
			if (n == c && buff != "") { v.push_back(buff); buff = ""; }
	}
	if (buff != "") v.push_back(buff);

	return v;
}
