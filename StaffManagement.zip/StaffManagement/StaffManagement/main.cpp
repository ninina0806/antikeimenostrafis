#include "StaffController.h"
#include "Core.h"
#include <iostream>
#include <algorithm>
#include <cctype>

const std::string FILENAME = "staff.txt";
StaffController* controller = NULL;

bool is_number(std::string& s) {
	return !s.empty() && std::find_if(s.begin(),
		s.end(), [](char c) { return !std::isdigit(c); }) == s.end();
}

void showMenu() {
	std::string choice = "-1";
	std::cout << " ---- MENU ----" << std::endl;
	std::cout << "1. Show all staff" << std::endl;
	std::cout << "2. Insert new staff" << std::endl;
	std::cout << "3. Update staff" << std::endl;
	std::cout << "4. Delete staff" << std::endl;
	std::cout << "5. Sort staff" << std::endl;
	std::cout << "6. Exit" << std::endl;
	std::getline(std::cin, choice);

	bool is_input_valid = false;
	while (!is_input_valid) {
		if (std::cin.fail() || !is_number(choice)) {
			std::cerr << "Sorry, I cannot read that. Please try again." << std::endl;
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::getline(std::cin, choice);
		}

		else if (std::stoi(choice) < MENU_SHOW_ALL || std::stoi(choice) > MENU_EXIT) {
			std::cerr << "Sorry, the number is out of range." << std::endl;
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::getline(std::cin, choice);
		}

		else {
			int choice_code = std::stoi(choice);
			switch (choice_code) {
			case MENU_SHOW_ALL:
				controller->showAll();
				break;
			case MENU_INSERT:
				std::vector<std::string> attrs;
				bool is_insert_input_valid = false;
				std::string staff_info = "";
				std::cout << "Please provide name, contract start (dd/mm/yyyy), contract end (dd/mm/yyyy) and salary of new staff" << std::endl;
				std::cout << "Put the " << ATTR_SEPERATOR << " character between attributes" << std::endl;
				std::getline(std::cin, staff_info);
				while (!is_insert_input_valid) {
					if (std::cin.fail()) {
						std::cerr << "Sorry, I cannot read that. Please try again." << std::endl;
						std::cin.clear();
						std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
						std::getline(std::cin, staff_info);
					}

					std::vector<std::string> attrs = Core::explode(staff_info, ATTR_SEPERATOR);
					if (attrs.size() < 4) {
						std::cerr << "Not enough arguments. Please try again." << std::endl;
						std::cin.clear();
						std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
						std::getline(std::cin, staff_info);
					}
					else {
						std::string name = attrs[0], salary = attrs[3], contract_start, contract_end;
						std::vector<std::string> contract_start_attrs = Core::explode(attrs[1], '/');
						std::vector<std::string> contract_end_attrs = Core::explode(attrs[2], '/');
						if (contract_start_attrs.size() != 3) {
							std::cerr << "Wrong format in contract start date. Please try again." << std::endl;
							std::cin.clear();
							std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							std::getline(std::cin, staff_info);
						}
						else if (!Core::formatDate(std::stoi(contract_start_attrs[0]), std::stoi(contract_start_attrs[1]), std::stoi(contract_start_attrs[2]), contract_start)) {
							std::cerr << "Wrong inputs in contract start date. Please try again." << std::endl;
							std::cin.clear();
							std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							std::getline(std::cin, staff_info);
						}
						else if (contract_end_attrs.size() != 3) {
							std::cerr << "Wrong format in contract end date. Please try again." << std::endl;
							std::cin.clear();
							std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							std::getline(std::cin, staff_info);
						}
						else if (!Core::formatDate(std::stoi(contract_end_attrs[0]), std::stoi(contract_end_attrs[1]), std::stoi(contract_end_attrs[2]), contract_end)) {
							std::cerr << "Wrong inputs in contract end date. Please try again." << std::endl;
							std::cin.clear();
							std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							std::getline(std::cin, staff_info);
						}
						else if (!is_number(salary)) {
							std::cerr << "Salary is not a number. Please try again." << std::endl;
							std::cin.clear();
							std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							std::getline(std::cin, staff_info);
						}
						else {
							controller->insertStaff(attrs);
							std::cout << "Successfully inserted new staff!" << std::endl;
							is_insert_input_valid = true;
							showMenu();
						}
					}
				}
				break;
			}
		}

		is_input_valid = true;
	}

}

int main() {
	Core::init();

	controller = new StaffController();
	std::fstream* staff_file = NULL;
	if (Core::openFile(FILENAME, std::ios_base::in, staff_file)) {
		controller->updateStaff(staff_file);
		showMenu();
		while (Core::isAppRunning()) {}
	}

	delete controller;
	controller = NULL;

	getchar();
	return 0;

}

