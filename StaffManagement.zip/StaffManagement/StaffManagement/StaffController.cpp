#include "StaffController.h"
#include "Core.h"
#include <fstream>
#include <iostream>

// https://www.tutorialspoint.com/cplusplus/cpp_files_streams.htm

int LAST_ID = -1;

StaffController::StaffController() {}
StaffController::~StaffController() {
	for (Staff* staff : staff_list) staff_list.remove(staff);
}

void StaffController::updateStaff(std::fstream* _file) {
	std::cout << _file << std::endl;
	std::string file_contents((std::istreambuf_iterator<char>(*_file)),
		std::istreambuf_iterator<char>());

	std::vector<std::string> cmb_staff = Core::explode(file_contents, STAFF_SEPERATOR);
	for (std::string staff_info : cmb_staff) {
		std::vector<std::string> staff_attrs = Core::explode(staff_info, ATTR_SEPERATOR);
		insertStaff(staff_attrs);
	}

	staff_list.sort(sort_id);
}

void StaffController::showAll() {
	for (Staff* staff : staff_list) staff->printInfo();
}

void StaffController::saveToFile(std::fstream* _file) {
	std::string file_contents;
	for (Staff* staff : staff_list) {
		std::string info = std::to_string(staff->getId()) + ATTR_SEPERATOR;
		info += staff->getName() + ATTR_SEPERATOR;
		info += staff->getContractStart() + ATTR_SEPERATOR;
		info += staff->getContractEnd() +ATTR_SEPERATOR;
		info += std::to_string(staff->getSalary());
		file_contents += info + STAFF_SEPERATOR;
	}

	*_file << file_contents;
	_file->close();
}

Staff* StaffController::getStaff(int _id) {
	for (Staff* staff : staff_list) {
		if (staff->getId() == _id) return staff;
	}
	return NULL;
}

void StaffController::deleteStaff(int _id) {
	Staff* staff = getStaff(_id);
	if (staff) staff_list.remove(staff);
}

void StaffController::editStaff(int _id, StaffAttributes _attr, std::string _value) {
	Staff* staff = getStaff(_id);
	if (staff) {
		switch (_attr) {
		case ATTR_NAME:
			staff->setName(_value);
			break;
		case ATTR_CONTRACT_START:
			staff->setContractStart(_value);
			break;
		case ATTR_CONTRACT_END:
			staff->setContractEnd(_value);
			break;
		case ATTR_SALARY:
			staff->setSalary(std::stoi(_value));
			break;
		}
	}
}

void StaffController::insertStaff(std::vector<std::string> _attrs) {
	int id = 0;
	if (_attrs.size() == ATTR_TOTAL) {
		id = std::stoi(_attrs[ATTR_ID]);
		LAST_ID = (id > LAST_ID) ? id : LAST_ID;
	}
	else {
		id = ++LAST_ID;
		_attrs.insert(_attrs.begin(), std::to_string(id));
	}

	Staff* staff = new Staff(id);
	staff->setName(_attrs[ATTR_NAME]);
	staff->setContractStart(_attrs[ATTR_CONTRACT_START]);
	staff->setContractEnd(_attrs[ATTR_CONTRACT_END]);
	staff->setSalary(std::stoi(_attrs[ATTR_SALARY]));
	staff_list.push_back(staff);
}

std::vector<Staff*> StaffController::searchStaff(StaffAttributes _attr, std::string _value) {
	std::vector<Staff*> results;
	switch (_attr) {
	case ATTR_ID:
		results.push_back(getStaff(std::stoi(_value)));
		break;
	case ATTR_NAME:
		for (Staff* staff : staff_list)
			if (staff->getName() == _value) results.push_back(staff);
		break;
	case ATTR_CONTRACT_START:
		for (Staff* staff : staff_list)
			if (staff->getContractStart() == _value) results.push_back(staff);
		break;
	case ATTR_CONTRACT_END:
		for (Staff* staff : staff_list)
			if (staff->getContractEnd() == _value) results.push_back(staff);
		break;
	case ATTR_SALARY:
		for (Staff* staff : staff_list)
			if (staff->getSalary() == std::stoi(_value)) results.push_back(staff);
		break;
	}
	
	return results;
}