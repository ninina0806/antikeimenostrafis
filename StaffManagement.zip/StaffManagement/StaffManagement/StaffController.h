#ifndef STAFFCONTROLLER_H
#define STAFFCONTROLLER_H

#include "Staff.h"
#include <string>
#include <list>
#include <vector>
#include <functional>

enum StaffAttributes {
	ATTR_ID = 0,
	ATTR_NAME,
	ATTR_CONTRACT_START,
	ATTR_CONTRACT_END,
	ATTR_SALARY,
	ATTR_TOTAL
};

const char STAFF_SEPERATOR = '#';
const char ATTR_SEPERATOR = '!';

class StaffController {
public:
	StaffController();
	~StaffController();
	void deleteStaff(int _id);
	void editStaff(int _id, StaffAttributes _attr, std::string _value);
	void insertStaff(std::vector<std::string> _attrs);
	std::vector<Staff*> searchStaff(StaffAttributes _attr, std::string _value);
	void showAll();
	
	void updateStaff(std::fstream* _file);
	void saveToFile(std::fstream* _file);
private:
	std::list<Staff*> staff_list;
	Staff* getStaff(int _id);
	std::function<bool(Staff* l_obj, Staff* r_obj)> sort_id = [](Staff* l_obj, Staff* r_obj) { return l_obj->getId() < r_obj->getId(); };
	std::function<bool(Staff* l_obj, Staff* r_obj)> sort_names = [](Staff* l_obj, Staff* r_obj) { return l_obj->getName().compare(r_obj->getName()) < 0; };
	std::function<bool(Staff* l_obj, Staff* r_obj)> sort_salary = [](Staff* l_obj, Staff* r_obj) { return l_obj->getSalary() < r_obj->getSalary(); };
};

#endif