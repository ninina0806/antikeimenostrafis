#ifndef CORE_H
#define CORE_H

#include <string>
#include <vector>



enum Months {
	JANUARY = 1,
	FEBRUARY,
	MARCH,
	APRIL,
	MAY,
	JUNE,
	JULY,
	AUGUST,
	SEPTEMBER,
	OCTOMBER,
	NOVEMBER,
	DECEMBER
};

enum MainMenu {
	MENU_SHOW_ALL = 1,
	MENU_INSERT,
	MENU_UPDATE,
	MENU_SEARCH,
	MENU_DELETE,
	MENU_SORT,
	MENU_EXIT
};

class Core {
public:
	static void init();
	static bool formatDate(int _day, int _month, int _year, std::string& _date);
	static bool checkInput(std::string _input);
	static bool openFile(std::string _filename, int _mode, std::fstream*& _file);
	static std::vector<std::string> explode(const std::string& s, const char& c);
	static bool isAppRunning();
	static void stopApp();
private:
	static bool checkDate(int _day, int _month, int _year);
	static bool isLeapYear(int _year);
};

#endif
